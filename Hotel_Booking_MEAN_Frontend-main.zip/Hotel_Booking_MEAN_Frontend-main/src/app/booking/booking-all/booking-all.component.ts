import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-all',
  templateUrl: './booking-all.component.html',
  styleUrls: ['./booking-all.component.css']
})
export class BookingAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
