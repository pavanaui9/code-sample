import { ListingFilterPipe } from './listing-filter.pipe';

describe('ListingFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ListingFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
