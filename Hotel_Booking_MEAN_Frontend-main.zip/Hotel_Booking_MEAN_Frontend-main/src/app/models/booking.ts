export class Booking {
  listing_id!: string;
  booking_id!: string;
  booking_date!: Date;
  booking_start!: Date;
  booking_end!: Date;
  username!: string;
}
