import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listing-all',
  templateUrl: './listing-all.component.html',
  styleUrls: ['./listing-all.component.css']
})
export class ListingAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
