import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-all',
  templateUrl: './users-all.component.html',
  styleUrls: ['./users-all.component.css']
})
export class UsersAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
