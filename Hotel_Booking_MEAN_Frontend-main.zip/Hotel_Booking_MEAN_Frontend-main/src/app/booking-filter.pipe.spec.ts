import { BookingFilterPipe } from './booking-filter.pipe';

describe('BookingFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BookingFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
